$(document).ready(function() {
    $('#calculate').click(function() {
        var amount = parseFloat($('#amount').val());
        var taxRate = parseFloat($('#taxRate').val());
        var transactionType = $('input[name="transactionType"]:checked').val();
        var amountType = $('input[name="amountType"]:checked').val();

        if (!isNaN(amount) && amount > 0 && !isNaN(taxRate)) {
            var resultHtml = '';

            if (amountType == 'exclusive') {
                if (transactionType == 'intrastate') {
                    var tax = (amount * taxRate) / 100;
                    var cgst = tax / 2;
                    var sgst = tax / 2;
                    var total = amount + tax;

                    resultHtml += `<p>Base Amount: <strong>Rs. ${amount.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>CGST: <strong>Rs. ${cgst.toFixed(2)}</strong>, SGST: <strong>Rs. ${sgst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Total GST: <strong>Rs. ${tax.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Final Amount: <strong>Rs. ${total.toFixed(2)}</strong></p>`;

                } else {  // Interstate (IGST)
                    var igst = (amount * taxRate) / 100;
                    var total = amount + igst;

                    resultHtml += `<p>Base Amount: <strong>Rs. ${amount.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>IGST: <strong>Rs. ${igst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Total GST: <strong>Rs. ${igst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Final Amount: <strong>Rs. ${total.toFixed(2)}</strong></p>`;
                }
            } else {  // Inclusive Amount Calculation
                var baseAmount = amount / (1 + taxRate / 100);
                var tax = amount - baseAmount;

                if (transactionType == 'intrastate') {
                    var cgst = tax / 2;
                    var sgst = tax / 2;

                    resultHtml += `<p>Base Amount: <strong>Rs. ${baseAmount.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>CGST: <strong>Rs. ${cgst.toFixed(2)}</strong>, SGST: <strong>Rs. ${sgst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Total GST: <strong>Rs. ${tax.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Final Amount: <strong>Rs. ${amount.toFixed(2)}</strong></p>`;

                } else {  // Interstate (IGST)
                    var igst = tax;

                    resultHtml += `<p>Base Amount: <strong>Rs. ${baseAmount.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>IGST: <strong>Rs. ${igst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Total GST: <strong>Rs. ${igst.toFixed(2)}</strong></p>`;
                    resultHtml += `<p>Final Amount: <strong>Rs. ${amount.toFixed(2)}</strong></p>`;
                }
            }

            $('#result').html(resultHtml);
        } else {
            $('#result').html('<p style="color: red;">Please enter a valid amount and select a tax rate.</p>');
        }
    });
});
